from django.contrib import admin
from django.urls import path, include
from babu import views



urlpatterns = [
        path("", views.index, name='babu' ),
        path("sweetu", views.sweetu, name='sweetu' ),
    
]

