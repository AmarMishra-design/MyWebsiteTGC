from django.shortcuts import render

# Create your views here.
def index(request):
    # return HttpResponse("This is home page")
    return render(request, 'index.html')

def sweetu(request):
    # return HttpResponse("This is home page")
    return render(request, 'sweetu.html')