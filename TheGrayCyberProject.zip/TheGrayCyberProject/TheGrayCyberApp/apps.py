from django.apps import AppConfig


class ThegraycyberappConfig(AppConfig):
    name = 'TheGrayCyberApp'
