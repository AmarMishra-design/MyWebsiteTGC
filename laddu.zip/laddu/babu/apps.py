from django.apps import AppConfig


class BabuConfig(AppConfig):
    name = 'babu'
