from django.contrib import admin
from django.urls import path
from TheGrayCyberApp import views

urlpatterns = [
    path("", views.index, name='TheGrayCyberApp' ),
    path("about", views.about, name='about' ),
    path("services", views.about, name='services' ),
    path("contact", views.contact, name='contact' ),
    
    
]